# hexo-front-matter

[![CI](https://github.com/hexojs/hexo-front-matter/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/hexojs/hexo-front-matter/actions/workflows/ci.yml)
[![NPM version](https://badge.fury.io/js/hexo-front-matter.svg)](https://www.npmjs.com/package/hexo-front-matter)
[![Coverage Status](https://coveralls.io/repos/github/hexojs/hexo-front-matter/badge.svg)](https://coveralls.io/github/hexojs/hexo-front-matter)

Front-matter parser.

## What is Front-matter?

Front-matter allows you to specify data at the top of a file. Here are two formats:

**YAML front-matter**

```
---
layout: false
title: "Hello world"
---
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
```

**JSON front-matter**

```
;;;
"layout": false,
"title": "Hello world"
;;;
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
```

Prefixing separators are optional.

## API

### parse(str, [options])

Parses front-matter.

### stringify(obj, [options])

Converts an object to a front-matter string.

Option | Description | Default
--- | --- | ---
`mode` | The mode can be either `json` or `yaml`. | `yaml`
`separator` | Separator | `---`
`prefixSeparator` | Add prefixing separator. | `false`

### split(str)

Splits a YAML front-matter string.

### escape(str)

Converts hard tabs to soft tabs.

## License

MIT